package org.openqa.selenium.devtools.v143.autofill.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

public class AddressField {

    private final java.lang.String name;

    private final java.lang.String value;

    public AddressField(java.lang.String name, java.lang.String value) {
        this.name = java.util.Objects.requireNonNull(name, "name is required");
        this.value = java.util.Objects.requireNonNull(value, "value is required");
    }

    /**
     * address field name, for example GIVEN_NAME.
     * The full list of supported field names:
     * https://source.chromium.org/chromium/chromium/src/+/main:components/autofill/core/browser/field_types.cc;l=38
     */
    public java.lang.String getName() {
        return name;
    }

    /**
     * address field value, for example Jon Doe.
     */
    public java.lang.String getValue() {
        return value;
    }

    private static AddressField fromJson(JsonInput input) {
        java.lang.String name = null;
        java.lang.String value = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "name":
                    name = input.nextString();
                    break;
                case "value":
                    value = input.nextString();
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new AddressField(name, value);
    }
}
