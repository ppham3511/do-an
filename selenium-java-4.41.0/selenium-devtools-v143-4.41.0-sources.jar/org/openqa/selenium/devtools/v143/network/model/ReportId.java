package org.openqa.selenium.devtools.v143.network.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class ReportId {

    private final java.lang.String reportId;

    public ReportId(java.lang.String reportId) {
        this.reportId = java.util.Objects.requireNonNull(reportId, "Missing value for ReportId");
    }

    private static ReportId fromJson(JsonInput input) {
        return new ReportId(input.nextString());
    }

    public String toJson() {
        return reportId.toString();
    }

    public String toString() {
        return reportId.toString();
    }
}
