package org.openqa.selenium.devtools.v143.storage.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class AttributionReportingAggregatableDedupKey {

    private final java.util.Optional<org.openqa.selenium.devtools.v143.storage.model.UnsignedInt64AsBase10> dedupKey;

    private final org.openqa.selenium.devtools.v143.storage.model.AttributionReportingFilterPair filters;

    public AttributionReportingAggregatableDedupKey(java.util.Optional<org.openqa.selenium.devtools.v143.storage.model.UnsignedInt64AsBase10> dedupKey, org.openqa.selenium.devtools.v143.storage.model.AttributionReportingFilterPair filters) {
        this.dedupKey = dedupKey;
        this.filters = java.util.Objects.requireNonNull(filters, "filters is required");
    }

    public java.util.Optional<org.openqa.selenium.devtools.v143.storage.model.UnsignedInt64AsBase10> getDedupKey() {
        return dedupKey;
    }

    public org.openqa.selenium.devtools.v143.storage.model.AttributionReportingFilterPair getFilters() {
        return filters;
    }

    private static AttributionReportingAggregatableDedupKey fromJson(JsonInput input) {
        java.util.Optional<org.openqa.selenium.devtools.v143.storage.model.UnsignedInt64AsBase10> dedupKey = java.util.Optional.empty();
        org.openqa.selenium.devtools.v143.storage.model.AttributionReportingFilterPair filters = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "dedupKey":
                    dedupKey = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v143.storage.model.UnsignedInt64AsBase10.class));
                    break;
                case "filters":
                    filters = input.read(org.openqa.selenium.devtools.v143.storage.model.AttributionReportingFilterPair.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new AttributionReportingAggregatableDedupKey(dedupKey, filters);
    }
}
