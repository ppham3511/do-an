package org.openqa.selenium.devtools.v143.storage.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class AttributionReportingAggregationKeysEntry {

    private final java.lang.String key;

    private final org.openqa.selenium.devtools.v143.storage.model.UnsignedInt128AsBase16 value;

    public AttributionReportingAggregationKeysEntry(java.lang.String key, org.openqa.selenium.devtools.v143.storage.model.UnsignedInt128AsBase16 value) {
        this.key = java.util.Objects.requireNonNull(key, "key is required");
        this.value = java.util.Objects.requireNonNull(value, "value is required");
    }

    public java.lang.String getKey() {
        return key;
    }

    public org.openqa.selenium.devtools.v143.storage.model.UnsignedInt128AsBase16 getValue() {
        return value;
    }

    private static AttributionReportingAggregationKeysEntry fromJson(JsonInput input) {
        java.lang.String key = null;
        org.openqa.selenium.devtools.v143.storage.model.UnsignedInt128AsBase16 value = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "key":
                    key = input.nextString();
                    break;
                case "value":
                    value = input.read(org.openqa.selenium.devtools.v143.storage.model.UnsignedInt128AsBase16.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new AttributionReportingAggregationKeysEntry(key, value);
    }
}
