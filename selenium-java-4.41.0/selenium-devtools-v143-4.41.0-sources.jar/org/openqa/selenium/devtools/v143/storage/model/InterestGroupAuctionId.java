package org.openqa.selenium.devtools.v143.storage.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Protected audience interest group auction identifier.
 */
public class InterestGroupAuctionId {

    private final java.lang.String interestGroupAuctionId;

    public InterestGroupAuctionId(java.lang.String interestGroupAuctionId) {
        this.interestGroupAuctionId = java.util.Objects.requireNonNull(interestGroupAuctionId, "Missing value for InterestGroupAuctionId");
    }

    private static InterestGroupAuctionId fromJson(JsonInput input) {
        return new InterestGroupAuctionId(input.nextString());
    }

    public String toJson() {
        return interestGroupAuctionId.toString();
    }

    public String toString() {
        return interestGroupAuctionId.toString();
    }
}
