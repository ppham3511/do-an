package org.openqa.selenium.devtools.v143.storage.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class SignedInt64AsBase10 {

    private final java.lang.String signedInt64AsBase10;

    public SignedInt64AsBase10(java.lang.String signedInt64AsBase10) {
        this.signedInt64AsBase10 = java.util.Objects.requireNonNull(signedInt64AsBase10, "Missing value for SignedInt64AsBase10");
    }

    private static SignedInt64AsBase10 fromJson(JsonInput input) {
        return new SignedInt64AsBase10(input.nextString());
    }

    public String toJson() {
        return signedInt64AsBase10.toString();
    }

    public String toString() {
        return signedInt64AsBase10.toString();
    }
}
