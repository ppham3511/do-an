package org.openqa.selenium.devtools.v144.audits.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

public class FederatedAuthUserInfoRequestIssueDetails {

    private final org.openqa.selenium.devtools.v144.audits.model.FederatedAuthUserInfoRequestIssueReason federatedAuthUserInfoRequestIssueReason;

    public FederatedAuthUserInfoRequestIssueDetails(org.openqa.selenium.devtools.v144.audits.model.FederatedAuthUserInfoRequestIssueReason federatedAuthUserInfoRequestIssueReason) {
        this.federatedAuthUserInfoRequestIssueReason = java.util.Objects.requireNonNull(federatedAuthUserInfoRequestIssueReason, "federatedAuthUserInfoRequestIssueReason is required");
    }

    public org.openqa.selenium.devtools.v144.audits.model.FederatedAuthUserInfoRequestIssueReason getFederatedAuthUserInfoRequestIssueReason() {
        return federatedAuthUserInfoRequestIssueReason;
    }

    private static FederatedAuthUserInfoRequestIssueDetails fromJson(JsonInput input) {
        org.openqa.selenium.devtools.v144.audits.model.FederatedAuthUserInfoRequestIssueReason federatedAuthUserInfoRequestIssueReason = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "federatedAuthUserInfoRequestIssueReason":
                    federatedAuthUserInfoRequestIssueReason = input.read(org.openqa.selenium.devtools.v144.audits.model.FederatedAuthUserInfoRequestIssueReason.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new FederatedAuthUserInfoRequestIssueDetails(federatedAuthUserInfoRequestIssueReason);
    }
}
