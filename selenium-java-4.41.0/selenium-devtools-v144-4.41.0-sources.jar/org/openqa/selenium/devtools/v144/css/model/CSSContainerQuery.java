package org.openqa.selenium.devtools.v144.css.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * CSS container query rule descriptor.
 */
@org.openqa.selenium.Beta()
public class CSSContainerQuery {

    private final java.lang.String text;

    private final java.util.Optional<org.openqa.selenium.devtools.v144.css.model.SourceRange> range;

    private final java.util.Optional<org.openqa.selenium.devtools.v144.dom.model.StyleSheetId> styleSheetId;

    private final java.util.Optional<java.lang.String> name;

    private final java.util.Optional<org.openqa.selenium.devtools.v144.dom.model.PhysicalAxes> physicalAxes;

    private final java.util.Optional<org.openqa.selenium.devtools.v144.dom.model.LogicalAxes> logicalAxes;

    private final java.util.Optional<java.lang.Boolean> queriesScrollState;

    private final java.util.Optional<java.lang.Boolean> queriesAnchored;

    public CSSContainerQuery(java.lang.String text, java.util.Optional<org.openqa.selenium.devtools.v144.css.model.SourceRange> range, java.util.Optional<org.openqa.selenium.devtools.v144.dom.model.StyleSheetId> styleSheetId, java.util.Optional<java.lang.String> name, java.util.Optional<org.openqa.selenium.devtools.v144.dom.model.PhysicalAxes> physicalAxes, java.util.Optional<org.openqa.selenium.devtools.v144.dom.model.LogicalAxes> logicalAxes, java.util.Optional<java.lang.Boolean> queriesScrollState, java.util.Optional<java.lang.Boolean> queriesAnchored) {
        this.text = java.util.Objects.requireNonNull(text, "text is required");
        this.range = range;
        this.styleSheetId = styleSheetId;
        this.name = name;
        this.physicalAxes = physicalAxes;
        this.logicalAxes = logicalAxes;
        this.queriesScrollState = queriesScrollState;
        this.queriesAnchored = queriesAnchored;
    }

    /**
     * Container query text.
     */
    public java.lang.String getText() {
        return text;
    }

    /**
     * The associated rule header range in the enclosing stylesheet (if
     * available).
     */
    public java.util.Optional<org.openqa.selenium.devtools.v144.css.model.SourceRange> getRange() {
        return range;
    }

    /**
     * Identifier of the stylesheet containing this object (if exists).
     */
    public java.util.Optional<org.openqa.selenium.devtools.v144.dom.model.StyleSheetId> getStyleSheetId() {
        return styleSheetId;
    }

    /**
     * Optional name for the container.
     */
    public java.util.Optional<java.lang.String> getName() {
        return name;
    }

    /**
     * Optional physical axes queried for the container.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v144.dom.model.PhysicalAxes> getPhysicalAxes() {
        return physicalAxes;
    }

    /**
     * Optional logical axes queried for the container.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v144.dom.model.LogicalAxes> getLogicalAxes() {
        return logicalAxes;
    }

    /**
     * true if the query contains scroll-state() queries.
     */
    public java.util.Optional<java.lang.Boolean> getQueriesScrollState() {
        return queriesScrollState;
    }

    /**
     * true if the query contains anchored() queries.
     */
    public java.util.Optional<java.lang.Boolean> getQueriesAnchored() {
        return queriesAnchored;
    }

    private static CSSContainerQuery fromJson(JsonInput input) {
        java.lang.String text = null;
        java.util.Optional<org.openqa.selenium.devtools.v144.css.model.SourceRange> range = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v144.dom.model.StyleSheetId> styleSheetId = java.util.Optional.empty();
        java.util.Optional<java.lang.String> name = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v144.dom.model.PhysicalAxes> physicalAxes = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v144.dom.model.LogicalAxes> logicalAxes = java.util.Optional.empty();
        java.util.Optional<java.lang.Boolean> queriesScrollState = java.util.Optional.empty();
        java.util.Optional<java.lang.Boolean> queriesAnchored = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "text":
                    text = input.nextString();
                    break;
                case "range":
                    range = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v144.css.model.SourceRange.class));
                    break;
                case "styleSheetId":
                    styleSheetId = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v144.dom.model.StyleSheetId.class));
                    break;
                case "name":
                    name = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "physicalAxes":
                    physicalAxes = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v144.dom.model.PhysicalAxes.class));
                    break;
                case "logicalAxes":
                    logicalAxes = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v144.dom.model.LogicalAxes.class));
                    break;
                case "queriesScrollState":
                    queriesScrollState = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                case "queriesAnchored":
                    queriesAnchored = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new CSSContainerQuery(text, range, styleSheetId, name, physicalAxes, logicalAxes, queriesScrollState, queriesAnchored);
    }
}
