package org.openqa.selenium.devtools.v144.emulation.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class PressureMetadata {

    private final java.util.Optional<java.lang.Boolean> available;

    public PressureMetadata(java.util.Optional<java.lang.Boolean> available) {
        this.available = available;
    }

    public java.util.Optional<java.lang.Boolean> getAvailable() {
        return available;
    }

    private static PressureMetadata fromJson(JsonInput input) {
        java.util.Optional<java.lang.Boolean> available = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "available":
                    available = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new PressureMetadata(available);
    }
}
