package org.openqa.selenium.devtools.v144.memory;

import org.openqa.selenium.Beta;
import org.openqa.selenium.devtools.Command;
import org.openqa.selenium.devtools.Event;
import org.openqa.selenium.devtools.ConverterFunctions;
import java.util.Map;
import java.util.LinkedHashMap;
import org.openqa.selenium.json.JsonInput;

@Beta()
public class Memory {

    public static class GetDOMCountersResponse {

        private final java.lang.Integer documents;

        private final java.lang.Integer nodes;

        private final java.lang.Integer jsEventListeners;

        public GetDOMCountersResponse(java.lang.Integer documents, java.lang.Integer nodes, java.lang.Integer jsEventListeners) {
            this.documents = java.util.Objects.requireNonNull(documents, "documents is required");
            this.nodes = java.util.Objects.requireNonNull(nodes, "nodes is required");
            this.jsEventListeners = java.util.Objects.requireNonNull(jsEventListeners, "jsEventListeners is required");
        }

        public java.lang.Integer getDocuments() {
            return documents;
        }

        public java.lang.Integer getNodes() {
            return nodes;
        }

        public java.lang.Integer getJsEventListeners() {
            return jsEventListeners;
        }

        private static GetDOMCountersResponse fromJson(JsonInput input) {
            java.lang.Integer documents = 0;
            java.lang.Integer nodes = 0;
            java.lang.Integer jsEventListeners = 0;
            input.beginObject();
            while (input.hasNext()) {
                switch(input.nextName()) {
                    case "documents":
                        documents = input.nextNumber().intValue();
                        break;
                    case "nodes":
                        nodes = input.nextNumber().intValue();
                        break;
                    case "jsEventListeners":
                        jsEventListeners = input.nextNumber().intValue();
                        break;
                    default:
                        input.skipValue();
                        break;
                }
            }
            input.endObject();
            return new GetDOMCountersResponse(documents, nodes, jsEventListeners);
        }
    }

    /**
     * Retruns current DOM object counters.
     */
    public static Command<org.openqa.selenium.devtools.v144.memory.Memory.GetDOMCountersResponse> getDOMCounters() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("Memory.getDOMCounters", Map.copyOf(params), input -> input.read(org.openqa.selenium.devtools.v144.memory.Memory.GetDOMCountersResponse.class));
    }

    /**
     * Retruns DOM object counters after preparing renderer for leak detection.
     */
    public static Command<java.util.List<org.openqa.selenium.devtools.v144.memory.model.DOMCounter>> getDOMCountersForLeakDetection() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("Memory.getDOMCountersForLeakDetection", Map.copyOf(params), ConverterFunctions.map("counters", input -> input.readArray(org.openqa.selenium.devtools.v144.memory.model.DOMCounter.class)));
    }

    /**
     * Prepares for leak detection by terminating workers, stopping spellcheckers,
     * dropping non-essential internal caches, running garbage collections, etc.
     */
    public static Command<Void> prepareForLeakDetection() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("Memory.prepareForLeakDetection", Map.copyOf(params));
    }

    /**
     * Simulate OomIntervention by purging V8 memory.
     */
    public static Command<Void> forciblyPurgeJavaScriptMemory() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("Memory.forciblyPurgeJavaScriptMemory", Map.copyOf(params));
    }

    /**
     * Enable/disable suppressing memory pressure notifications in all processes.
     */
    public static Command<Void> setPressureNotificationsSuppressed(java.lang.Boolean suppressed) {
        java.util.Objects.requireNonNull(suppressed, "suppressed is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("suppressed", suppressed);
        return new Command<>("Memory.setPressureNotificationsSuppressed", Map.copyOf(params));
    }

    /**
     * Simulate a memory pressure notification in all processes.
     */
    public static Command<Void> simulatePressureNotification(org.openqa.selenium.devtools.v144.memory.model.PressureLevel level) {
        java.util.Objects.requireNonNull(level, "level is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("level", level);
        return new Command<>("Memory.simulatePressureNotification", Map.copyOf(params));
    }

    /**
     * Start collecting native memory profile.
     */
    public static Command<Void> startSampling(java.util.Optional<java.lang.Integer> samplingInterval, java.util.Optional<java.lang.Boolean> suppressRandomness) {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        samplingInterval.ifPresent(p -> params.put("samplingInterval", p));
        suppressRandomness.ifPresent(p -> params.put("suppressRandomness", p));
        return new Command<>("Memory.startSampling", Map.copyOf(params));
    }

    /**
     * Stop collecting native memory profile.
     */
    public static Command<Void> stopSampling() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("Memory.stopSampling", Map.copyOf(params));
    }

    /**
     * Retrieve native memory allocations profile
     * collected since renderer process startup.
     */
    public static Command<org.openqa.selenium.devtools.v144.memory.model.SamplingProfile> getAllTimeSamplingProfile() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("Memory.getAllTimeSamplingProfile", Map.copyOf(params), ConverterFunctions.map("profile", org.openqa.selenium.devtools.v144.memory.model.SamplingProfile.class));
    }

    /**
     * Retrieve native memory allocations profile
     * collected since browser process startup.
     */
    public static Command<org.openqa.selenium.devtools.v144.memory.model.SamplingProfile> getBrowserSamplingProfile() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("Memory.getBrowserSamplingProfile", Map.copyOf(params), ConverterFunctions.map("profile", org.openqa.selenium.devtools.v144.memory.model.SamplingProfile.class));
    }

    /**
     * Retrieve native memory allocations profile collected since last
     * `startSampling` call.
     */
    public static Command<org.openqa.selenium.devtools.v144.memory.model.SamplingProfile> getSamplingProfile() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("Memory.getSamplingProfile", Map.copyOf(params), ConverterFunctions.map("profile", org.openqa.selenium.devtools.v144.memory.model.SamplingProfile.class));
    }
}
