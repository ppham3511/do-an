package org.openqa.selenium.devtools.v144.network.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Cookie parameter object
 */
public class CookieParam {

    private final java.lang.String name;

    private final java.lang.String value;

    private final java.util.Optional<java.lang.String> url;

    private final java.util.Optional<java.lang.String> domain;

    private final java.util.Optional<java.lang.String> path;

    private final java.util.Optional<java.lang.Boolean> secure;

    private final java.util.Optional<java.lang.Boolean> httpOnly;

    private final java.util.Optional<org.openqa.selenium.devtools.v144.network.model.CookieSameSite> sameSite;

    private final java.util.Optional<org.openqa.selenium.devtools.v144.network.model.TimeSinceEpoch> expires;

    private final java.util.Optional<org.openqa.selenium.devtools.v144.network.model.CookiePriority> priority;

    private final java.util.Optional<java.lang.Boolean> sameParty;

    private final java.util.Optional<org.openqa.selenium.devtools.v144.network.model.CookieSourceScheme> sourceScheme;

    private final java.util.Optional<java.lang.Integer> sourcePort;

    private final java.util.Optional<org.openqa.selenium.devtools.v144.network.model.CookiePartitionKey> partitionKey;

    public CookieParam(java.lang.String name, java.lang.String value, java.util.Optional<java.lang.String> url, java.util.Optional<java.lang.String> domain, java.util.Optional<java.lang.String> path, java.util.Optional<java.lang.Boolean> secure, java.util.Optional<java.lang.Boolean> httpOnly, java.util.Optional<org.openqa.selenium.devtools.v144.network.model.CookieSameSite> sameSite, java.util.Optional<org.openqa.selenium.devtools.v144.network.model.TimeSinceEpoch> expires, java.util.Optional<org.openqa.selenium.devtools.v144.network.model.CookiePriority> priority, java.util.Optional<java.lang.Boolean> sameParty, java.util.Optional<org.openqa.selenium.devtools.v144.network.model.CookieSourceScheme> sourceScheme, java.util.Optional<java.lang.Integer> sourcePort, java.util.Optional<org.openqa.selenium.devtools.v144.network.model.CookiePartitionKey> partitionKey) {
        this.name = java.util.Objects.requireNonNull(name, "name is required");
        this.value = java.util.Objects.requireNonNull(value, "value is required");
        this.url = url;
        this.domain = domain;
        this.path = path;
        this.secure = secure;
        this.httpOnly = httpOnly;
        this.sameSite = sameSite;
        this.expires = expires;
        this.priority = priority;
        this.sameParty = sameParty;
        this.sourceScheme = sourceScheme;
        this.sourcePort = sourcePort;
        this.partitionKey = partitionKey;
    }

    /**
     * Cookie name.
     */
    public java.lang.String getName() {
        return name;
    }

    /**
     * Cookie value.
     */
    public java.lang.String getValue() {
        return value;
    }

    /**
     * The request-URI to associate with the setting of the cookie. This value can affect the
     * default domain, path, source port, and source scheme values of the created cookie.
     */
    public java.util.Optional<java.lang.String> getUrl() {
        return url;
    }

    /**
     * Cookie domain.
     */
    public java.util.Optional<java.lang.String> getDomain() {
        return domain;
    }

    /**
     * Cookie path.
     */
    public java.util.Optional<java.lang.String> getPath() {
        return path;
    }

    /**
     * True if cookie is secure.
     */
    public java.util.Optional<java.lang.Boolean> getSecure() {
        return secure;
    }

    /**
     * True if cookie is http-only.
     */
    public java.util.Optional<java.lang.Boolean> getHttpOnly() {
        return httpOnly;
    }

    /**
     * Cookie SameSite type.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v144.network.model.CookieSameSite> getSameSite() {
        return sameSite;
    }

    /**
     * Cookie expiration date, session cookie if not set
     */
    public java.util.Optional<org.openqa.selenium.devtools.v144.network.model.TimeSinceEpoch> getExpires() {
        return expires;
    }

    /**
     * Cookie Priority.
     */
    @Beta()
    public java.util.Optional<org.openqa.selenium.devtools.v144.network.model.CookiePriority> getPriority() {
        return priority;
    }

    /**
     * True if cookie is SameParty.
     */
    @Beta()
    public java.util.Optional<java.lang.Boolean> getSameParty() {
        return sameParty;
    }

    /**
     * Cookie source scheme type.
     */
    @Beta()
    public java.util.Optional<org.openqa.selenium.devtools.v144.network.model.CookieSourceScheme> getSourceScheme() {
        return sourceScheme;
    }

    /**
     * Cookie source port. Valid values are {-1, [1, 65535]}, -1 indicates an unspecified port.
     * An unspecified port value allows protocol clients to emulate legacy cookie scope for the port.
     * This is a temporary ability and it will be removed in the future.
     */
    @Beta()
    public java.util.Optional<java.lang.Integer> getSourcePort() {
        return sourcePort;
    }

    /**
     * Cookie partition key. If not set, the cookie will be set as not partitioned.
     */
    @Beta()
    public java.util.Optional<org.openqa.selenium.devtools.v144.network.model.CookiePartitionKey> getPartitionKey() {
        return partitionKey;
    }

    private static CookieParam fromJson(JsonInput input) {
        java.lang.String name = null;
        java.lang.String value = null;
        java.util.Optional<java.lang.String> url = java.util.Optional.empty();
        java.util.Optional<java.lang.String> domain = java.util.Optional.empty();
        java.util.Optional<java.lang.String> path = java.util.Optional.empty();
        java.util.Optional<java.lang.Boolean> secure = java.util.Optional.empty();
        java.util.Optional<java.lang.Boolean> httpOnly = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v144.network.model.CookieSameSite> sameSite = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v144.network.model.TimeSinceEpoch> expires = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v144.network.model.CookiePriority> priority = java.util.Optional.empty();
        java.util.Optional<java.lang.Boolean> sameParty = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v144.network.model.CookieSourceScheme> sourceScheme = java.util.Optional.empty();
        java.util.Optional<java.lang.Integer> sourcePort = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v144.network.model.CookiePartitionKey> partitionKey = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "name":
                    name = input.nextString();
                    break;
                case "value":
                    value = input.nextString();
                    break;
                case "url":
                    url = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "domain":
                    domain = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "path":
                    path = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "secure":
                    secure = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                case "httpOnly":
                    httpOnly = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                case "sameSite":
                    sameSite = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v144.network.model.CookieSameSite.class));
                    break;
                case "expires":
                    expires = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v144.network.model.TimeSinceEpoch.class));
                    break;
                case "priority":
                    priority = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v144.network.model.CookiePriority.class));
                    break;
                case "sameParty":
                    sameParty = java.util.Optional.ofNullable(input.nextBoolean());
                    break;
                case "sourceScheme":
                    sourceScheme = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v144.network.model.CookieSourceScheme.class));
                    break;
                case "sourcePort":
                    sourcePort = java.util.Optional.ofNullable(input.nextNumber().intValue());
                    break;
                case "partitionKey":
                    partitionKey = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v144.network.model.CookiePartitionKey.class));
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new CookieParam(name, value, url, domain, path, secure, httpOnly, sameSite, expires, priority, sameParty, sourceScheme, sourcePort, partitionKey);
    }
}
