package org.openqa.selenium.devtools.v144.page.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * List of not restored reasons for back-forward cache.
 */
@org.openqa.selenium.Beta()
public enum BackForwardCacheNotRestoredReason {

    NOTPRIMARYMAINFRAME("NotPrimaryMainFrame"),
    BACKFORWARDCACHEDISABLED("BackForwardCacheDisabled"),
    RELATEDACTIVECONTENTSEXIST("RelatedActiveContentsExist"),
    HTTPSTATUSNOTOK("HTTPStatusNotOK"),
    SCHEMENOTHTTPORHTTPS("SchemeNotHTTPOrHTTPS"),
    LOADING("Loading"),
    WASGRANTEDMEDIAACCESS("WasGrantedMediaAccess"),
    DISABLEFORRENDERFRAMEHOSTCALLED("DisableForRenderFrameHostCalled"),
    DOMAINNOTALLOWED("DomainNotAllowed"),
    HTTPMETHODNOTGET("HTTPMethodNotGET"),
    SUBFRAMEISNAVIGATING("SubframeIsNavigating"),
    TIMEOUT("Timeout"),
    CACHELIMIT("CacheLimit"),
    JAVASCRIPTEXECUTION("JavaScriptExecution"),
    RENDERERPROCESSKILLED("RendererProcessKilled"),
    RENDERERPROCESSCRASHED("RendererProcessCrashed"),
    SCHEDULERTRACKEDFEATUREUSED("SchedulerTrackedFeatureUsed"),
    CONFLICTINGBROWSINGINSTANCE("ConflictingBrowsingInstance"),
    CACHEFLUSHED("CacheFlushed"),
    SERVICEWORKERVERSIONACTIVATION("ServiceWorkerVersionActivation"),
    SESSIONRESTORED("SessionRestored"),
    SERVICEWORKERPOSTMESSAGE("ServiceWorkerPostMessage"),
    ENTEREDBACKFORWARDCACHEBEFORESERVICEWORKERHOSTADDED("EnteredBackForwardCacheBeforeServiceWorkerHostAdded"),
    RENDERFRAMEHOSTREUSED_SAMESITE("RenderFrameHostReused_SameSite"),
    RENDERFRAMEHOSTREUSED_CROSSSITE("RenderFrameHostReused_CrossSite"),
    SERVICEWORKERCLAIM("ServiceWorkerClaim"),
    IGNOREEVENTANDEVICT("IgnoreEventAndEvict"),
    HAVEINNERCONTENTS("HaveInnerContents"),
    TIMEOUTPUTTINGINCACHE("TimeoutPuttingInCache"),
    BACKFORWARDCACHEDISABLEDBYLOWMEMORY("BackForwardCacheDisabledByLowMemory"),
    BACKFORWARDCACHEDISABLEDBYCOMMANDLINE("BackForwardCacheDisabledByCommandLine"),
    NETWORKREQUESTDATAPIPEDRAINEDASBYTESCONSUMER("NetworkRequestDatapipeDrainedAsBytesConsumer"),
    NETWORKREQUESTREDIRECTED("NetworkRequestRedirected"),
    NETWORKREQUESTTIMEOUT("NetworkRequestTimeout"),
    NETWORKEXCEEDSBUFFERLIMIT("NetworkExceedsBufferLimit"),
    NAVIGATIONCANCELLEDWHILERESTORING("NavigationCancelledWhileRestoring"),
    NOTMOSTRECENTNAVIGATIONENTRY("NotMostRecentNavigationEntry"),
    BACKFORWARDCACHEDISABLEDFORPRERENDER("BackForwardCacheDisabledForPrerender"),
    USERAGENTOVERRIDEDIFFERS("UserAgentOverrideDiffers"),
    FOREGROUNDCACHELIMIT("ForegroundCacheLimit"),
    BROWSINGINSTANCENOTSWAPPED("BrowsingInstanceNotSwapped"),
    BACKFORWARDCACHEDISABLEDFORDELEGATE("BackForwardCacheDisabledForDelegate"),
    UNLOADHANDLEREXISTSINMAINFRAME("UnloadHandlerExistsInMainFrame"),
    UNLOADHANDLEREXISTSINSUBFRAME("UnloadHandlerExistsInSubFrame"),
    SERVICEWORKERUNREGISTRATION("ServiceWorkerUnregistration"),
    CACHECONTROLNOSTORE("CacheControlNoStore"),
    CACHECONTROLNOSTORECOOKIEMODIFIED("CacheControlNoStoreCookieModified"),
    CACHECONTROLNOSTOREHTTPONLYCOOKIEMODIFIED("CacheControlNoStoreHTTPOnlyCookieModified"),
    NORESPONSEHEAD("NoResponseHead"),
    UNKNOWN("Unknown"),
    ACTIVATIONNAVIGATIONSDISALLOWEDFORBUG1234857("ActivationNavigationsDisallowedForBug1234857"),
    ERRORDOCUMENT("ErrorDocument"),
    FENCEDFRAMESEMBEDDER("FencedFramesEmbedder"),
    COOKIEDISABLED("CookieDisabled"),
    HTTPAUTHREQUIRED("HTTPAuthRequired"),
    COOKIEFLUSHED("CookieFlushed"),
    BROADCASTCHANNELONMESSAGE("BroadcastChannelOnMessage"),
    WEBVIEWSETTINGSCHANGED("WebViewSettingsChanged"),
    WEBVIEWJAVASCRIPTOBJECTCHANGED("WebViewJavaScriptObjectChanged"),
    WEBVIEWMESSAGELISTENERINJECTED("WebViewMessageListenerInjected"),
    WEBVIEWSAFEBROWSINGALLOWLISTCHANGED("WebViewSafeBrowsingAllowlistChanged"),
    WEBVIEWDOCUMENTSTARTJAVASCRIPTCHANGED("WebViewDocumentStartJavascriptChanged"),
    WEBSOCKET("WebSocket"),
    WEBTRANSPORT("WebTransport"),
    WEBRTC("WebRTC"),
    MAINRESOURCEHASCACHECONTROLNOSTORE("MainResourceHasCacheControlNoStore"),
    MAINRESOURCEHASCACHECONTROLNOCACHE("MainResourceHasCacheControlNoCache"),
    SUBRESOURCEHASCACHECONTROLNOSTORE("SubresourceHasCacheControlNoStore"),
    SUBRESOURCEHASCACHECONTROLNOCACHE("SubresourceHasCacheControlNoCache"),
    CONTAINSPLUGINS("ContainsPlugins"),
    DOCUMENTLOADED("DocumentLoaded"),
    OUTSTANDINGNETWORKREQUESTOTHERS("OutstandingNetworkRequestOthers"),
    REQUESTEDMIDIPERMISSION("RequestedMIDIPermission"),
    REQUESTEDAUDIOCAPTUREPERMISSION("RequestedAudioCapturePermission"),
    REQUESTEDVIDEOCAPTUREPERMISSION("RequestedVideoCapturePermission"),
    REQUESTEDBACKFORWARDCACHEBLOCKEDSENSORS("RequestedBackForwardCacheBlockedSensors"),
    REQUESTEDBACKGROUNDWORKPERMISSION("RequestedBackgroundWorkPermission"),
    BROADCASTCHANNEL("BroadcastChannel"),
    WEBXR("WebXR"),
    SHAREDWORKER("SharedWorker"),
    SHAREDWORKERMESSAGE("SharedWorkerMessage"),
    SHAREDWORKERWITHNOACTIVECLIENT("SharedWorkerWithNoActiveClient"),
    WEBLOCKS("WebLocks"),
    WEBHID("WebHID"),
    WEBBLUETOOTH("WebBluetooth"),
    WEBSHARE("WebShare"),
    REQUESTEDSTORAGEACCESSGRANT("RequestedStorageAccessGrant"),
    WEBNFC("WebNfc"),
    OUTSTANDINGNETWORKREQUESTFETCH("OutstandingNetworkRequestFetch"),
    OUTSTANDINGNETWORKREQUESTXHR("OutstandingNetworkRequestXHR"),
    APPBANNER("AppBanner"),
    PRINTING("Printing"),
    WEBDATABASE("WebDatabase"),
    PICTUREINPICTURE("PictureInPicture"),
    SPEECHRECOGNIZER("SpeechRecognizer"),
    IDLEMANAGER("IdleManager"),
    PAYMENTMANAGER("PaymentManager"),
    SPEECHSYNTHESIS("SpeechSynthesis"),
    KEYBOARDLOCK("KeyboardLock"),
    WEBOTPSERVICE("WebOTPService"),
    OUTSTANDINGNETWORKREQUESTDIRECTSOCKET("OutstandingNetworkRequestDirectSocket"),
    INJECTEDJAVASCRIPT("InjectedJavascript"),
    INJECTEDSTYLESHEET("InjectedStyleSheet"),
    KEEPALIVEREQUEST("KeepaliveRequest"),
    INDEXEDDBEVENT("IndexedDBEvent"),
    DUMMY("Dummy"),
    JSNETWORKREQUESTRECEIVEDCACHECONTROLNOSTORERESOURCE("JsNetworkRequestReceivedCacheControlNoStoreResource"),
    WEBRTCUSEDWITHCCNS("WebRTCUsedWithCCNS"),
    WEBTRANSPORTUSEDWITHCCNS("WebTransportUsedWithCCNS"),
    WEBSOCKETUSEDWITHCCNS("WebSocketUsedWithCCNS"),
    SMARTCARD("SmartCard"),
    LIVEMEDIASTREAMTRACK("LiveMediaStreamTrack"),
    UNLOADHANDLER("UnloadHandler"),
    PARSERABORTED("ParserAborted"),
    CONTENTSECURITYHANDLER("ContentSecurityHandler"),
    CONTENTWEBAUTHENTICATIONAPI("ContentWebAuthenticationAPI"),
    CONTENTFILECHOOSER("ContentFileChooser"),
    CONTENTSERIAL("ContentSerial"),
    CONTENTFILESYSTEMACCESS("ContentFileSystemAccess"),
    CONTENTMEDIADEVICESDISPATCHERHOST("ContentMediaDevicesDispatcherHost"),
    CONTENTWEBBLUETOOTH("ContentWebBluetooth"),
    CONTENTWEBUSB("ContentWebUSB"),
    CONTENTMEDIASESSIONSERVICE("ContentMediaSessionService"),
    CONTENTSCREENREADER("ContentScreenReader"),
    CONTENTDISCARDED("ContentDiscarded"),
    EMBEDDERPOPUPBLOCKERTABHELPER("EmbedderPopupBlockerTabHelper"),
    EMBEDDERSAFEBROWSINGTRIGGEREDPOPUPBLOCKER("EmbedderSafeBrowsingTriggeredPopupBlocker"),
    EMBEDDERSAFEBROWSINGTHREATDETAILS("EmbedderSafeBrowsingThreatDetails"),
    EMBEDDERAPPBANNERMANAGER("EmbedderAppBannerManager"),
    EMBEDDERDOMDISTILLERVIEWERSOURCE("EmbedderDomDistillerViewerSource"),
    EMBEDDERDOMDISTILLERSELFDELETINGREQUESTDELEGATE("EmbedderDomDistillerSelfDeletingRequestDelegate"),
    EMBEDDEROOMINTERVENTIONTABHELPER("EmbedderOomInterventionTabHelper"),
    EMBEDDEROFFLINEPAGE("EmbedderOfflinePage"),
    EMBEDDERCHROMEPASSWORDMANAGERCLIENTBINDCREDENTIALMANAGER("EmbedderChromePasswordManagerClientBindCredentialManager"),
    EMBEDDERPERMISSIONREQUESTMANAGER("EmbedderPermissionRequestManager"),
    EMBEDDERMODALDIALOG("EmbedderModalDialog"),
    EMBEDDEREXTENSIONS("EmbedderExtensions"),
    EMBEDDEREXTENSIONMESSAGING("EmbedderExtensionMessaging"),
    EMBEDDEREXTENSIONMESSAGINGFOROPENPORT("EmbedderExtensionMessagingForOpenPort"),
    EMBEDDEREXTENSIONSENTMESSAGETOCACHEDFRAME("EmbedderExtensionSentMessageToCachedFrame"),
    REQUESTEDBYWEBVIEWCLIENT("RequestedByWebViewClient"),
    POSTMESSAGEBYWEBVIEWCLIENT("PostMessageByWebViewClient"),
    CACHECONTROLNOSTOREDEVICEBOUNDSESSIONTERMINATED("CacheControlNoStoreDeviceBoundSessionTerminated"),
    CACHELIMITPRUNEDONMODERATEMEMORYPRESSURE("CacheLimitPrunedOnModerateMemoryPressure"),
    CACHELIMITPRUNEDONCRITICALMEMORYPRESSURE("CacheLimitPrunedOnCriticalMemoryPressure");

    private String value;

    BackForwardCacheNotRestoredReason(String value) {
        this.value = value;
    }

    public static BackForwardCacheNotRestoredReason fromString(String s) {
        return java.util.Arrays.stream(BackForwardCacheNotRestoredReason.values()).filter(rs -> rs.value.equalsIgnoreCase(s)).findFirst().orElseThrow(() -> new org.openqa.selenium.devtools.DevToolsException("Given value " + s + " is not found within BackForwardCacheNotRestoredReason "));
    }

    public String toString() {
        return value;
    }

    public String toJson() {
        return value;
    }

    private static BackForwardCacheNotRestoredReason fromJson(JsonInput input) {
        return fromString(input.nextString());
    }
}
