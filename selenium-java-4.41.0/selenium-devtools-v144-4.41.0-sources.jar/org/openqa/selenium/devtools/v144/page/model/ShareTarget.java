package org.openqa.selenium.devtools.v144.page.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class ShareTarget {

    private final java.lang.String action;

    private final java.lang.String method;

    private final java.lang.String enctype;

    private final java.util.Optional<java.lang.String> title;

    private final java.util.Optional<java.lang.String> text;

    private final java.util.Optional<java.lang.String> url;

    private final java.util.Optional<java.util.List<org.openqa.selenium.devtools.v144.page.model.FileFilter>> files;

    public ShareTarget(java.lang.String action, java.lang.String method, java.lang.String enctype, java.util.Optional<java.lang.String> title, java.util.Optional<java.lang.String> text, java.util.Optional<java.lang.String> url, java.util.Optional<java.util.List<org.openqa.selenium.devtools.v144.page.model.FileFilter>> files) {
        this.action = java.util.Objects.requireNonNull(action, "action is required");
        this.method = java.util.Objects.requireNonNull(method, "method is required");
        this.enctype = java.util.Objects.requireNonNull(enctype, "enctype is required");
        this.title = title;
        this.text = text;
        this.url = url;
        this.files = files;
    }

    public java.lang.String getAction() {
        return action;
    }

    public java.lang.String getMethod() {
        return method;
    }

    public java.lang.String getEnctype() {
        return enctype;
    }

    /**
     * Embed the ShareTargetParams
     */
    public java.util.Optional<java.lang.String> getTitle() {
        return title;
    }

    public java.util.Optional<java.lang.String> getText() {
        return text;
    }

    public java.util.Optional<java.lang.String> getUrl() {
        return url;
    }

    public java.util.Optional<java.util.List<org.openqa.selenium.devtools.v144.page.model.FileFilter>> getFiles() {
        return files;
    }

    private static ShareTarget fromJson(JsonInput input) {
        java.lang.String action = null;
        java.lang.String method = null;
        java.lang.String enctype = null;
        java.util.Optional<java.lang.String> title = java.util.Optional.empty();
        java.util.Optional<java.lang.String> text = java.util.Optional.empty();
        java.util.Optional<java.lang.String> url = java.util.Optional.empty();
        java.util.Optional<java.util.List<org.openqa.selenium.devtools.v144.page.model.FileFilter>> files = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "action":
                    action = input.nextString();
                    break;
                case "method":
                    method = input.nextString();
                    break;
                case "enctype":
                    enctype = input.nextString();
                    break;
                case "title":
                    title = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "text":
                    text = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "url":
                    url = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "files":
                    files = java.util.Optional.ofNullable(input.readArray(org.openqa.selenium.devtools.v144.page.model.FileFilter.class));
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new ShareTarget(action, method, enctype, title, text, url, files);
    }
}
