package org.openqa.selenium.devtools.v144.runtime.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Represents function call argument. Either remote object id `objectId`, primitive `value`,
 * unserializable primitive value or neither of (for undefined) them should be specified.
 */
public class CallArgument {

    private final java.util.Optional<java.lang.Object> value;

    private final java.util.Optional<org.openqa.selenium.devtools.v144.runtime.model.UnserializableValue> unserializableValue;

    private final java.util.Optional<org.openqa.selenium.devtools.v144.runtime.model.RemoteObjectId> objectId;

    public CallArgument(java.util.Optional<java.lang.Object> value, java.util.Optional<org.openqa.selenium.devtools.v144.runtime.model.UnserializableValue> unserializableValue, java.util.Optional<org.openqa.selenium.devtools.v144.runtime.model.RemoteObjectId> objectId) {
        this.value = value;
        this.unserializableValue = unserializableValue;
        this.objectId = objectId;
    }

    /**
     * Primitive value or serializable javascript object.
     */
    public java.util.Optional<java.lang.Object> getValue() {
        return value;
    }

    /**
     * Primitive value which can not be JSON-stringified.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v144.runtime.model.UnserializableValue> getUnserializableValue() {
        return unserializableValue;
    }

    /**
     * Remote object handle.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v144.runtime.model.RemoteObjectId> getObjectId() {
        return objectId;
    }

    private static CallArgument fromJson(JsonInput input) {
        java.util.Optional<java.lang.Object> value = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v144.runtime.model.UnserializableValue> unserializableValue = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v144.runtime.model.RemoteObjectId> objectId = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "value":
                    value = java.util.Optional.ofNullable(input.read(Object.class));
                    break;
                case "unserializableValue":
                    unserializableValue = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v144.runtime.model.UnserializableValue.class));
                    break;
                case "objectId":
                    objectId = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v144.runtime.model.RemoteObjectId.class));
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new CallArgument(value, unserializableValue, objectId);
    }
}
