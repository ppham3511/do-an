package org.openqa.selenium.devtools.v144.runtime.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class EntryPreview {

    private final java.util.Optional<org.openqa.selenium.devtools.v144.runtime.model.ObjectPreview> key;

    private final org.openqa.selenium.devtools.v144.runtime.model.ObjectPreview value;

    public EntryPreview(java.util.Optional<org.openqa.selenium.devtools.v144.runtime.model.ObjectPreview> key, org.openqa.selenium.devtools.v144.runtime.model.ObjectPreview value) {
        this.key = key;
        this.value = java.util.Objects.requireNonNull(value, "value is required");
    }

    /**
     * Preview of the key. Specified for map-like collection entries.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v144.runtime.model.ObjectPreview> getKey() {
        return key;
    }

    /**
     * Preview of the value.
     */
    public org.openqa.selenium.devtools.v144.runtime.model.ObjectPreview getValue() {
        return value;
    }

    private static EntryPreview fromJson(JsonInput input) {
        java.util.Optional<org.openqa.selenium.devtools.v144.runtime.model.ObjectPreview> key = java.util.Optional.empty();
        org.openqa.selenium.devtools.v144.runtime.model.ObjectPreview value = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "key":
                    key = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v144.runtime.model.ObjectPreview.class));
                    break;
                case "value":
                    value = input.read(org.openqa.selenium.devtools.v144.runtime.model.ObjectPreview.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new EntryPreview(key, value);
    }
}
