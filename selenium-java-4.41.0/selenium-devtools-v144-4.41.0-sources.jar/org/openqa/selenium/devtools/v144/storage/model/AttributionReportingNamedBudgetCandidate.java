package org.openqa.selenium.devtools.v144.storage.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class AttributionReportingNamedBudgetCandidate {

    private final java.util.Optional<java.lang.String> name;

    private final org.openqa.selenium.devtools.v144.storage.model.AttributionReportingFilterPair filters;

    public AttributionReportingNamedBudgetCandidate(java.util.Optional<java.lang.String> name, org.openqa.selenium.devtools.v144.storage.model.AttributionReportingFilterPair filters) {
        this.name = name;
        this.filters = java.util.Objects.requireNonNull(filters, "filters is required");
    }

    public java.util.Optional<java.lang.String> getName() {
        return name;
    }

    public org.openqa.selenium.devtools.v144.storage.model.AttributionReportingFilterPair getFilters() {
        return filters;
    }

    private static AttributionReportingNamedBudgetCandidate fromJson(JsonInput input) {
        java.util.Optional<java.lang.String> name = java.util.Optional.empty();
        org.openqa.selenium.devtools.v144.storage.model.AttributionReportingFilterPair filters = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "name":
                    name = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "filters":
                    filters = input.read(org.openqa.selenium.devtools.v144.storage.model.AttributionReportingFilterPair.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new AttributionReportingNamedBudgetCandidate(name, filters);
    }
}
