package org.openqa.selenium.devtools.v144.storage.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class AttributionReportingSourceRegistered {

    private final org.openqa.selenium.devtools.v144.storage.model.AttributionReportingSourceRegistration registration;

    private final org.openqa.selenium.devtools.v144.storage.model.AttributionReportingSourceRegistrationResult result;

    public AttributionReportingSourceRegistered(org.openqa.selenium.devtools.v144.storage.model.AttributionReportingSourceRegistration registration, org.openqa.selenium.devtools.v144.storage.model.AttributionReportingSourceRegistrationResult result) {
        this.registration = java.util.Objects.requireNonNull(registration, "registration is required");
        this.result = java.util.Objects.requireNonNull(result, "result is required");
    }

    public org.openqa.selenium.devtools.v144.storage.model.AttributionReportingSourceRegistration getRegistration() {
        return registration;
    }

    public org.openqa.selenium.devtools.v144.storage.model.AttributionReportingSourceRegistrationResult getResult() {
        return result;
    }

    private static AttributionReportingSourceRegistered fromJson(JsonInput input) {
        org.openqa.selenium.devtools.v144.storage.model.AttributionReportingSourceRegistration registration = null;
        org.openqa.selenium.devtools.v144.storage.model.AttributionReportingSourceRegistrationResult result = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "registration":
                    registration = input.read(org.openqa.selenium.devtools.v144.storage.model.AttributionReportingSourceRegistration.class);
                    break;
                case "result":
                    result = input.read(org.openqa.selenium.devtools.v144.storage.model.AttributionReportingSourceRegistrationResult.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new AttributionReportingSourceRegistered(registration, result);
    }
}
