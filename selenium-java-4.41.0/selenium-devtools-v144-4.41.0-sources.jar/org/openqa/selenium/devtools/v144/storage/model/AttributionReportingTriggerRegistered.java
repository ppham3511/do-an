package org.openqa.selenium.devtools.v144.storage.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class AttributionReportingTriggerRegistered {

    private final org.openqa.selenium.devtools.v144.storage.model.AttributionReportingTriggerRegistration registration;

    private final org.openqa.selenium.devtools.v144.storage.model.AttributionReportingEventLevelResult eventLevel;

    private final org.openqa.selenium.devtools.v144.storage.model.AttributionReportingAggregatableResult aggregatable;

    public AttributionReportingTriggerRegistered(org.openqa.selenium.devtools.v144.storage.model.AttributionReportingTriggerRegistration registration, org.openqa.selenium.devtools.v144.storage.model.AttributionReportingEventLevelResult eventLevel, org.openqa.selenium.devtools.v144.storage.model.AttributionReportingAggregatableResult aggregatable) {
        this.registration = java.util.Objects.requireNonNull(registration, "registration is required");
        this.eventLevel = java.util.Objects.requireNonNull(eventLevel, "eventLevel is required");
        this.aggregatable = java.util.Objects.requireNonNull(aggregatable, "aggregatable is required");
    }

    public org.openqa.selenium.devtools.v144.storage.model.AttributionReportingTriggerRegistration getRegistration() {
        return registration;
    }

    public org.openqa.selenium.devtools.v144.storage.model.AttributionReportingEventLevelResult getEventLevel() {
        return eventLevel;
    }

    public org.openqa.selenium.devtools.v144.storage.model.AttributionReportingAggregatableResult getAggregatable() {
        return aggregatable;
    }

    private static AttributionReportingTriggerRegistered fromJson(JsonInput input) {
        org.openqa.selenium.devtools.v144.storage.model.AttributionReportingTriggerRegistration registration = null;
        org.openqa.selenium.devtools.v144.storage.model.AttributionReportingEventLevelResult eventLevel = null;
        org.openqa.selenium.devtools.v144.storage.model.AttributionReportingAggregatableResult aggregatable = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "registration":
                    registration = input.read(org.openqa.selenium.devtools.v144.storage.model.AttributionReportingTriggerRegistration.class);
                    break;
                case "eventLevel":
                    eventLevel = input.read(org.openqa.selenium.devtools.v144.storage.model.AttributionReportingEventLevelResult.class);
                    break;
                case "aggregatable":
                    aggregatable = input.read(org.openqa.selenium.devtools.v144.storage.model.AttributionReportingAggregatableResult.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new AttributionReportingTriggerRegistered(registration, eventLevel, aggregatable);
    }
}
