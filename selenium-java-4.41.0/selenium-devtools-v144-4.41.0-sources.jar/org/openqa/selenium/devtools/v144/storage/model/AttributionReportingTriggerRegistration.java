package org.openqa.selenium.devtools.v144.storage.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class AttributionReportingTriggerRegistration {

    private final org.openqa.selenium.devtools.v144.storage.model.AttributionReportingFilterPair filters;

    private final java.util.Optional<org.openqa.selenium.devtools.v144.storage.model.UnsignedInt64AsBase10> debugKey;

    private final java.util.List<org.openqa.selenium.devtools.v144.storage.model.AttributionReportingAggregatableDedupKey> aggregatableDedupKeys;

    private final java.util.List<org.openqa.selenium.devtools.v144.storage.model.AttributionReportingEventTriggerData> eventTriggerData;

    private final java.util.List<org.openqa.selenium.devtools.v144.storage.model.AttributionReportingAggregatableTriggerData> aggregatableTriggerData;

    private final java.util.List<org.openqa.selenium.devtools.v144.storage.model.AttributionReportingAggregatableValueEntry> aggregatableValues;

    private final java.lang.Integer aggregatableFilteringIdMaxBytes;

    private final java.lang.Boolean debugReporting;

    private final java.util.Optional<java.lang.String> aggregationCoordinatorOrigin;

    private final org.openqa.selenium.devtools.v144.storage.model.AttributionReportingSourceRegistrationTimeConfig sourceRegistrationTimeConfig;

    private final java.util.Optional<java.lang.String> triggerContextId;

    private final org.openqa.selenium.devtools.v144.storage.model.AttributionReportingAggregatableDebugReportingConfig aggregatableDebugReportingConfig;

    private final java.util.List<java.lang.String> scopes;

    private final java.util.List<org.openqa.selenium.devtools.v144.storage.model.AttributionReportingNamedBudgetCandidate> namedBudgets;

    public AttributionReportingTriggerRegistration(org.openqa.selenium.devtools.v144.storage.model.AttributionReportingFilterPair filters, java.util.Optional<org.openqa.selenium.devtools.v144.storage.model.UnsignedInt64AsBase10> debugKey, java.util.List<org.openqa.selenium.devtools.v144.storage.model.AttributionReportingAggregatableDedupKey> aggregatableDedupKeys, java.util.List<org.openqa.selenium.devtools.v144.storage.model.AttributionReportingEventTriggerData> eventTriggerData, java.util.List<org.openqa.selenium.devtools.v144.storage.model.AttributionReportingAggregatableTriggerData> aggregatableTriggerData, java.util.List<org.openqa.selenium.devtools.v144.storage.model.AttributionReportingAggregatableValueEntry> aggregatableValues, java.lang.Integer aggregatableFilteringIdMaxBytes, java.lang.Boolean debugReporting, java.util.Optional<java.lang.String> aggregationCoordinatorOrigin, org.openqa.selenium.devtools.v144.storage.model.AttributionReportingSourceRegistrationTimeConfig sourceRegistrationTimeConfig, java.util.Optional<java.lang.String> triggerContextId, org.openqa.selenium.devtools.v144.storage.model.AttributionReportingAggregatableDebugReportingConfig aggregatableDebugReportingConfig, java.util.List<java.lang.String> scopes, java.util.List<org.openqa.selenium.devtools.v144.storage.model.AttributionReportingNamedBudgetCandidate> namedBudgets) {
        this.filters = java.util.Objects.requireNonNull(filters, "filters is required");
        this.debugKey = debugKey;
        this.aggregatableDedupKeys = java.util.Objects.requireNonNull(aggregatableDedupKeys, "aggregatableDedupKeys is required");
        this.eventTriggerData = java.util.Objects.requireNonNull(eventTriggerData, "eventTriggerData is required");
        this.aggregatableTriggerData = java.util.Objects.requireNonNull(aggregatableTriggerData, "aggregatableTriggerData is required");
        this.aggregatableValues = java.util.Objects.requireNonNull(aggregatableValues, "aggregatableValues is required");
        this.aggregatableFilteringIdMaxBytes = java.util.Objects.requireNonNull(aggregatableFilteringIdMaxBytes, "aggregatableFilteringIdMaxBytes is required");
        this.debugReporting = java.util.Objects.requireNonNull(debugReporting, "debugReporting is required");
        this.aggregationCoordinatorOrigin = aggregationCoordinatorOrigin;
        this.sourceRegistrationTimeConfig = java.util.Objects.requireNonNull(sourceRegistrationTimeConfig, "sourceRegistrationTimeConfig is required");
        this.triggerContextId = triggerContextId;
        this.aggregatableDebugReportingConfig = java.util.Objects.requireNonNull(aggregatableDebugReportingConfig, "aggregatableDebugReportingConfig is required");
        this.scopes = java.util.Objects.requireNonNull(scopes, "scopes is required");
        this.namedBudgets = java.util.Objects.requireNonNull(namedBudgets, "namedBudgets is required");
    }

    public org.openqa.selenium.devtools.v144.storage.model.AttributionReportingFilterPair getFilters() {
        return filters;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v144.storage.model.UnsignedInt64AsBase10> getDebugKey() {
        return debugKey;
    }

    public java.util.List<org.openqa.selenium.devtools.v144.storage.model.AttributionReportingAggregatableDedupKey> getAggregatableDedupKeys() {
        return aggregatableDedupKeys;
    }

    public java.util.List<org.openqa.selenium.devtools.v144.storage.model.AttributionReportingEventTriggerData> getEventTriggerData() {
        return eventTriggerData;
    }

    public java.util.List<org.openqa.selenium.devtools.v144.storage.model.AttributionReportingAggregatableTriggerData> getAggregatableTriggerData() {
        return aggregatableTriggerData;
    }

    public java.util.List<org.openqa.selenium.devtools.v144.storage.model.AttributionReportingAggregatableValueEntry> getAggregatableValues() {
        return aggregatableValues;
    }

    public java.lang.Integer getAggregatableFilteringIdMaxBytes() {
        return aggregatableFilteringIdMaxBytes;
    }

    public java.lang.Boolean getDebugReporting() {
        return debugReporting;
    }

    public java.util.Optional<java.lang.String> getAggregationCoordinatorOrigin() {
        return aggregationCoordinatorOrigin;
    }

    public org.openqa.selenium.devtools.v144.storage.model.AttributionReportingSourceRegistrationTimeConfig getSourceRegistrationTimeConfig() {
        return sourceRegistrationTimeConfig;
    }

    public java.util.Optional<java.lang.String> getTriggerContextId() {
        return triggerContextId;
    }

    public org.openqa.selenium.devtools.v144.storage.model.AttributionReportingAggregatableDebugReportingConfig getAggregatableDebugReportingConfig() {
        return aggregatableDebugReportingConfig;
    }

    public java.util.List<java.lang.String> getScopes() {
        return scopes;
    }

    public java.util.List<org.openqa.selenium.devtools.v144.storage.model.AttributionReportingNamedBudgetCandidate> getNamedBudgets() {
        return namedBudgets;
    }

    private static AttributionReportingTriggerRegistration fromJson(JsonInput input) {
        org.openqa.selenium.devtools.v144.storage.model.AttributionReportingFilterPair filters = null;
        java.util.Optional<org.openqa.selenium.devtools.v144.storage.model.UnsignedInt64AsBase10> debugKey = java.util.Optional.empty();
        java.util.List<org.openqa.selenium.devtools.v144.storage.model.AttributionReportingAggregatableDedupKey> aggregatableDedupKeys = null;
        java.util.List<org.openqa.selenium.devtools.v144.storage.model.AttributionReportingEventTriggerData> eventTriggerData = null;
        java.util.List<org.openqa.selenium.devtools.v144.storage.model.AttributionReportingAggregatableTriggerData> aggregatableTriggerData = null;
        java.util.List<org.openqa.selenium.devtools.v144.storage.model.AttributionReportingAggregatableValueEntry> aggregatableValues = null;
        java.lang.Integer aggregatableFilteringIdMaxBytes = 0;
        java.lang.Boolean debugReporting = false;
        java.util.Optional<java.lang.String> aggregationCoordinatorOrigin = java.util.Optional.empty();
        org.openqa.selenium.devtools.v144.storage.model.AttributionReportingSourceRegistrationTimeConfig sourceRegistrationTimeConfig = null;
        java.util.Optional<java.lang.String> triggerContextId = java.util.Optional.empty();
        org.openqa.selenium.devtools.v144.storage.model.AttributionReportingAggregatableDebugReportingConfig aggregatableDebugReportingConfig = null;
        java.util.List<java.lang.String> scopes = null;
        java.util.List<org.openqa.selenium.devtools.v144.storage.model.AttributionReportingNamedBudgetCandidate> namedBudgets = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "filters":
                    filters = input.read(org.openqa.selenium.devtools.v144.storage.model.AttributionReportingFilterPair.class);
                    break;
                case "debugKey":
                    debugKey = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v144.storage.model.UnsignedInt64AsBase10.class));
                    break;
                case "aggregatableDedupKeys":
                    aggregatableDedupKeys = input.readArray(org.openqa.selenium.devtools.v144.storage.model.AttributionReportingAggregatableDedupKey.class);
                    break;
                case "eventTriggerData":
                    eventTriggerData = input.readArray(org.openqa.selenium.devtools.v144.storage.model.AttributionReportingEventTriggerData.class);
                    break;
                case "aggregatableTriggerData":
                    aggregatableTriggerData = input.readArray(org.openqa.selenium.devtools.v144.storage.model.AttributionReportingAggregatableTriggerData.class);
                    break;
                case "aggregatableValues":
                    aggregatableValues = input.readArray(org.openqa.selenium.devtools.v144.storage.model.AttributionReportingAggregatableValueEntry.class);
                    break;
                case "aggregatableFilteringIdMaxBytes":
                    aggregatableFilteringIdMaxBytes = input.nextNumber().intValue();
                    break;
                case "debugReporting":
                    debugReporting = input.nextBoolean();
                    break;
                case "aggregationCoordinatorOrigin":
                    aggregationCoordinatorOrigin = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "sourceRegistrationTimeConfig":
                    sourceRegistrationTimeConfig = input.read(org.openqa.selenium.devtools.v144.storage.model.AttributionReportingSourceRegistrationTimeConfig.class);
                    break;
                case "triggerContextId":
                    triggerContextId = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "aggregatableDebugReportingConfig":
                    aggregatableDebugReportingConfig = input.read(org.openqa.selenium.devtools.v144.storage.model.AttributionReportingAggregatableDebugReportingConfig.class);
                    break;
                case "scopes":
                    scopes = input.readArray(java.lang.String.class);
                    break;
                case "namedBudgets":
                    namedBudgets = input.readArray(org.openqa.selenium.devtools.v144.storage.model.AttributionReportingNamedBudgetCandidate.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new AttributionReportingTriggerRegistration(filters, debugKey, aggregatableDedupKeys, eventTriggerData, aggregatableTriggerData, aggregatableValues, aggregatableFilteringIdMaxBytes, debugReporting, aggregationCoordinatorOrigin, sourceRegistrationTimeConfig, triggerContextId, aggregatableDebugReportingConfig, scopes, namedBudgets);
    }
}
