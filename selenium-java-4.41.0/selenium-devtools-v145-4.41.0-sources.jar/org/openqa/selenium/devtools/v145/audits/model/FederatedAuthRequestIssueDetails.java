package org.openqa.selenium.devtools.v145.audits.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

public class FederatedAuthRequestIssueDetails {

    private final org.openqa.selenium.devtools.v145.audits.model.FederatedAuthRequestIssueReason federatedAuthRequestIssueReason;

    public FederatedAuthRequestIssueDetails(org.openqa.selenium.devtools.v145.audits.model.FederatedAuthRequestIssueReason federatedAuthRequestIssueReason) {
        this.federatedAuthRequestIssueReason = java.util.Objects.requireNonNull(federatedAuthRequestIssueReason, "federatedAuthRequestIssueReason is required");
    }

    public org.openqa.selenium.devtools.v145.audits.model.FederatedAuthRequestIssueReason getFederatedAuthRequestIssueReason() {
        return federatedAuthRequestIssueReason;
    }

    private static FederatedAuthRequestIssueDetails fromJson(JsonInput input) {
        org.openqa.selenium.devtools.v145.audits.model.FederatedAuthRequestIssueReason federatedAuthRequestIssueReason = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "federatedAuthRequestIssueReason":
                    federatedAuthRequestIssueReason = input.read(org.openqa.selenium.devtools.v145.audits.model.FederatedAuthRequestIssueReason.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new FederatedAuthRequestIssueDetails(federatedAuthRequestIssueReason);
    }
}
