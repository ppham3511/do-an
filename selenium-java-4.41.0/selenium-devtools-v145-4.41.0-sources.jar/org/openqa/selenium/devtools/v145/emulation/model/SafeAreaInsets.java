package org.openqa.selenium.devtools.v145.emulation.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class SafeAreaInsets {

    private final java.util.Optional<java.lang.Integer> top;

    private final java.util.Optional<java.lang.Integer> topMax;

    private final java.util.Optional<java.lang.Integer> left;

    private final java.util.Optional<java.lang.Integer> leftMax;

    private final java.util.Optional<java.lang.Integer> bottom;

    private final java.util.Optional<java.lang.Integer> bottomMax;

    private final java.util.Optional<java.lang.Integer> right;

    private final java.util.Optional<java.lang.Integer> rightMax;

    public SafeAreaInsets(java.util.Optional<java.lang.Integer> top, java.util.Optional<java.lang.Integer> topMax, java.util.Optional<java.lang.Integer> left, java.util.Optional<java.lang.Integer> leftMax, java.util.Optional<java.lang.Integer> bottom, java.util.Optional<java.lang.Integer> bottomMax, java.util.Optional<java.lang.Integer> right, java.util.Optional<java.lang.Integer> rightMax) {
        this.top = top;
        this.topMax = topMax;
        this.left = left;
        this.leftMax = leftMax;
        this.bottom = bottom;
        this.bottomMax = bottomMax;
        this.right = right;
        this.rightMax = rightMax;
    }

    /**
     * Overrides safe-area-inset-top.
     */
    public java.util.Optional<java.lang.Integer> getTop() {
        return top;
    }

    /**
     * Overrides safe-area-max-inset-top.
     */
    public java.util.Optional<java.lang.Integer> getTopMax() {
        return topMax;
    }

    /**
     * Overrides safe-area-inset-left.
     */
    public java.util.Optional<java.lang.Integer> getLeft() {
        return left;
    }

    /**
     * Overrides safe-area-max-inset-left.
     */
    public java.util.Optional<java.lang.Integer> getLeftMax() {
        return leftMax;
    }

    /**
     * Overrides safe-area-inset-bottom.
     */
    public java.util.Optional<java.lang.Integer> getBottom() {
        return bottom;
    }

    /**
     * Overrides safe-area-max-inset-bottom.
     */
    public java.util.Optional<java.lang.Integer> getBottomMax() {
        return bottomMax;
    }

    /**
     * Overrides safe-area-inset-right.
     */
    public java.util.Optional<java.lang.Integer> getRight() {
        return right;
    }

    /**
     * Overrides safe-area-max-inset-right.
     */
    public java.util.Optional<java.lang.Integer> getRightMax() {
        return rightMax;
    }

    private static SafeAreaInsets fromJson(JsonInput input) {
        java.util.Optional<java.lang.Integer> top = java.util.Optional.empty();
        java.util.Optional<java.lang.Integer> topMax = java.util.Optional.empty();
        java.util.Optional<java.lang.Integer> left = java.util.Optional.empty();
        java.util.Optional<java.lang.Integer> leftMax = java.util.Optional.empty();
        java.util.Optional<java.lang.Integer> bottom = java.util.Optional.empty();
        java.util.Optional<java.lang.Integer> bottomMax = java.util.Optional.empty();
        java.util.Optional<java.lang.Integer> right = java.util.Optional.empty();
        java.util.Optional<java.lang.Integer> rightMax = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "top":
                    top = java.util.Optional.ofNullable(input.nextNumber().intValue());
                    break;
                case "topMax":
                    topMax = java.util.Optional.ofNullable(input.nextNumber().intValue());
                    break;
                case "left":
                    left = java.util.Optional.ofNullable(input.nextNumber().intValue());
                    break;
                case "leftMax":
                    leftMax = java.util.Optional.ofNullable(input.nextNumber().intValue());
                    break;
                case "bottom":
                    bottom = java.util.Optional.ofNullable(input.nextNumber().intValue());
                    break;
                case "bottomMax":
                    bottomMax = java.util.Optional.ofNullable(input.nextNumber().intValue());
                    break;
                case "right":
                    right = java.util.Optional.ofNullable(input.nextNumber().intValue());
                    break;
                case "rightMax":
                    rightMax = java.util.Optional.ofNullable(input.nextNumber().intValue());
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new SafeAreaInsets(top, topMax, left, leftMax, bottom, bottomMax, right, rightMax);
    }
}
