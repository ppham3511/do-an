package org.openqa.selenium.devtools.v145.emulation.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class SensorReading {

    private final java.util.Optional<org.openqa.selenium.devtools.v145.emulation.model.SensorReadingSingle> single;

    private final java.util.Optional<org.openqa.selenium.devtools.v145.emulation.model.SensorReadingXYZ> xyz;

    private final java.util.Optional<org.openqa.selenium.devtools.v145.emulation.model.SensorReadingQuaternion> quaternion;

    public SensorReading(java.util.Optional<org.openqa.selenium.devtools.v145.emulation.model.SensorReadingSingle> single, java.util.Optional<org.openqa.selenium.devtools.v145.emulation.model.SensorReadingXYZ> xyz, java.util.Optional<org.openqa.selenium.devtools.v145.emulation.model.SensorReadingQuaternion> quaternion) {
        this.single = single;
        this.xyz = xyz;
        this.quaternion = quaternion;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v145.emulation.model.SensorReadingSingle> getSingle() {
        return single;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v145.emulation.model.SensorReadingXYZ> getXyz() {
        return xyz;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v145.emulation.model.SensorReadingQuaternion> getQuaternion() {
        return quaternion;
    }

    private static SensorReading fromJson(JsonInput input) {
        java.util.Optional<org.openqa.selenium.devtools.v145.emulation.model.SensorReadingSingle> single = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v145.emulation.model.SensorReadingXYZ> xyz = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v145.emulation.model.SensorReadingQuaternion> quaternion = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "single":
                    single = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v145.emulation.model.SensorReadingSingle.class));
                    break;
                case "xyz":
                    xyz = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v145.emulation.model.SensorReadingXYZ.class));
                    break;
                case "quaternion":
                    quaternion = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v145.emulation.model.SensorReadingQuaternion.class));
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new SensorReading(single, xyz, quaternion);
    }
}
