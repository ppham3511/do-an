package org.openqa.selenium.devtools.v145.storage.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class AttributionReportingAggregatableDebugReportingConfig {

    private final java.util.Optional<java.lang.Number> budget;

    private final org.openqa.selenium.devtools.v145.storage.model.UnsignedInt128AsBase16 keyPiece;

    private final java.util.List<org.openqa.selenium.devtools.v145.storage.model.AttributionReportingAggregatableDebugReportingData> debugData;

    private final java.util.Optional<java.lang.String> aggregationCoordinatorOrigin;

    public AttributionReportingAggregatableDebugReportingConfig(java.util.Optional<java.lang.Number> budget, org.openqa.selenium.devtools.v145.storage.model.UnsignedInt128AsBase16 keyPiece, java.util.List<org.openqa.selenium.devtools.v145.storage.model.AttributionReportingAggregatableDebugReportingData> debugData, java.util.Optional<java.lang.String> aggregationCoordinatorOrigin) {
        this.budget = budget;
        this.keyPiece = java.util.Objects.requireNonNull(keyPiece, "keyPiece is required");
        this.debugData = java.util.Objects.requireNonNull(debugData, "debugData is required");
        this.aggregationCoordinatorOrigin = aggregationCoordinatorOrigin;
    }

    /**
     * number instead of integer because not all uint32 can be represented by
     * int, only present for source registrations
     */
    public java.util.Optional<java.lang.Number> getBudget() {
        return budget;
    }

    public org.openqa.selenium.devtools.v145.storage.model.UnsignedInt128AsBase16 getKeyPiece() {
        return keyPiece;
    }

    public java.util.List<org.openqa.selenium.devtools.v145.storage.model.AttributionReportingAggregatableDebugReportingData> getDebugData() {
        return debugData;
    }

    public java.util.Optional<java.lang.String> getAggregationCoordinatorOrigin() {
        return aggregationCoordinatorOrigin;
    }

    private static AttributionReportingAggregatableDebugReportingConfig fromJson(JsonInput input) {
        java.util.Optional<java.lang.Number> budget = java.util.Optional.empty();
        org.openqa.selenium.devtools.v145.storage.model.UnsignedInt128AsBase16 keyPiece = null;
        java.util.List<org.openqa.selenium.devtools.v145.storage.model.AttributionReportingAggregatableDebugReportingData> debugData = null;
        java.util.Optional<java.lang.String> aggregationCoordinatorOrigin = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "budget":
                    budget = java.util.Optional.ofNullable(input.nextNumber());
                    break;
                case "keyPiece":
                    keyPiece = input.read(org.openqa.selenium.devtools.v145.storage.model.UnsignedInt128AsBase16.class);
                    break;
                case "debugData":
                    debugData = input.readArray(org.openqa.selenium.devtools.v145.storage.model.AttributionReportingAggregatableDebugReportingData.class);
                    break;
                case "aggregationCoordinatorOrigin":
                    aggregationCoordinatorOrigin = java.util.Optional.ofNullable(input.nextString());
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new AttributionReportingAggregatableDebugReportingConfig(budget, keyPiece, debugData, aggregationCoordinatorOrigin);
    }
}
