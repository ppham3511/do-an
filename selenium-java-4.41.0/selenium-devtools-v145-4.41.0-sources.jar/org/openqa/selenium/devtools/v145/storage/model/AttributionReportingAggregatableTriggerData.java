package org.openqa.selenium.devtools.v145.storage.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class AttributionReportingAggregatableTriggerData {

    private final org.openqa.selenium.devtools.v145.storage.model.UnsignedInt128AsBase16 keyPiece;

    private final java.util.List<java.lang.String> sourceKeys;

    private final org.openqa.selenium.devtools.v145.storage.model.AttributionReportingFilterPair filters;

    public AttributionReportingAggregatableTriggerData(org.openqa.selenium.devtools.v145.storage.model.UnsignedInt128AsBase16 keyPiece, java.util.List<java.lang.String> sourceKeys, org.openqa.selenium.devtools.v145.storage.model.AttributionReportingFilterPair filters) {
        this.keyPiece = java.util.Objects.requireNonNull(keyPiece, "keyPiece is required");
        this.sourceKeys = java.util.Objects.requireNonNull(sourceKeys, "sourceKeys is required");
        this.filters = java.util.Objects.requireNonNull(filters, "filters is required");
    }

    public org.openqa.selenium.devtools.v145.storage.model.UnsignedInt128AsBase16 getKeyPiece() {
        return keyPiece;
    }

    public java.util.List<java.lang.String> getSourceKeys() {
        return sourceKeys;
    }

    public org.openqa.selenium.devtools.v145.storage.model.AttributionReportingFilterPair getFilters() {
        return filters;
    }

    private static AttributionReportingAggregatableTriggerData fromJson(JsonInput input) {
        org.openqa.selenium.devtools.v145.storage.model.UnsignedInt128AsBase16 keyPiece = null;
        java.util.List<java.lang.String> sourceKeys = null;
        org.openqa.selenium.devtools.v145.storage.model.AttributionReportingFilterPair filters = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "keyPiece":
                    keyPiece = input.read(org.openqa.selenium.devtools.v145.storage.model.UnsignedInt128AsBase16.class);
                    break;
                case "sourceKeys":
                    sourceKeys = input.readArray(java.lang.String.class);
                    break;
                case "filters":
                    filters = input.read(org.openqa.selenium.devtools.v145.storage.model.AttributionReportingFilterPair.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new AttributionReportingAggregatableTriggerData(keyPiece, sourceKeys, filters);
    }
}
